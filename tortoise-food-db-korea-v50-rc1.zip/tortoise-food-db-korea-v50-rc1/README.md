# 거북밥 DB Korea v5.0-rc1
첫 통합 Release Candidate.
- plant master 66종 / static detail 66개
- 한글 오타검색, 다개체 프로필, 오늘 식단, 개체별 7일 기록
- JSON 백업/복원, PWA/offline shell
- 통합 상대링크·안전성 구조 QA
Integrated QA: PASS
